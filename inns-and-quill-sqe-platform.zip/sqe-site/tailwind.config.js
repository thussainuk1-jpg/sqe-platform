/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0F1419",
        parchment: "#F5F1E8",
        cream: "#FAF7F0",
        oxblood: "#7A1F2B",
        forest: "#1F3D2E",
        brass: "#B8923A",
        slate: "#5B6478",
        rule: "#D9D2BD",
      },
      fontFamily: {
        serif: ['"Cormorant Garamond"', "Georgia", "serif"],
        sans: ['"Inter"', "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
