#!/usr/bin/env node
// Seed: inserts a handful of CLEARLY-MARKED PLACEHOLDER questions so you can
// test the practice & mock flow end-to-end before you've authored real content.
// REPLACE OR DELETE these before going live. They are not SQE-quality material.

import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

const placeholders = [
  {
    stem: "[PLACEHOLDER — replace before publishing] In English contract law, an offer is best described as which of the following?",
    subject: "CONTRACT",
    difficulty: "EASY",
    explanation: "[PLACEHOLDER explanation] An offer is an expression of willingness to contract on specified terms, made with the intention that it shall become binding as soon as it is accepted (Storer v Manchester City Council [1974]). The other options describe related but distinct concepts (e.g. an invitation to treat).",
    source: "Placeholder — author your own",
    options: [
      { label: "A", text: "An invitation to treat displayed to the public.", isCorrect: false },
      { label: "B", text: "An expression of willingness to contract on specified terms, intended to bind on acceptance.", isCorrect: true },
      { label: "C", text: "A counter-offer that destroys the original.", isCorrect: false },
      { label: "D", text: "A mere puff with no legal weight.", isCorrect: false },
      { label: "E", text: "An exchange of consideration without intention to create legal relations.", isCorrect: false },
    ],
  },
  {
    stem: "[PLACEHOLDER — replace before publishing] Which of the following best describes the burden of proof in a criminal trial in England and Wales?",
    subject: "CRIMINAL_LAW",
    difficulty: "EASY",
    explanation: "[PLACEHOLDER explanation] The prosecution bears the legal burden of proving the defendant's guilt beyond reasonable doubt (Woolmington v DPP [1935]). Certain defences may impose an evidential burden on the defendant, but the overall legal burden remains with the prosecution.",
    source: "Placeholder — author your own",
    options: [
      { label: "A", text: "The defendant must prove their innocence on the balance of probabilities.", isCorrect: false },
      { label: "B", text: "The judge bears the burden of finding the truth.", isCorrect: false },
      { label: "C", text: "The prosecution must prove guilt beyond reasonable doubt.", isCorrect: true },
      { label: "D", text: "Both parties share the burden equally.", isCorrect: false },
      { label: "E", text: "The burden is decided by the jury before trial begins.", isCorrect: false },
    ],
  },
  {
    stem: "[PLACEHOLDER — replace before publishing] Which of the following is a core principle under the SRA Principles for solicitors?",
    subject: "ETHICS",
    difficulty: "MEDIUM",
    explanation: "[PLACEHOLDER explanation] The SRA Principles require solicitors to act, among other things, in a way that upholds the rule of law and the proper administration of justice, and with honesty and integrity. Maximising profit is not one of the Principles.",
    source: "Placeholder — author your own",
    options: [
      { label: "A", text: "Maximising fee income for the firm.", isCorrect: false },
      { label: "B", text: "Acting with honesty and integrity.", isCorrect: true },
      { label: "C", text: "Avoiding any pro bono work.", isCorrect: false },
      { label: "D", text: "Prioritising the firm over the client at all times.", isCorrect: false },
      { label: "E", text: "Refusing to engage with regulators.", isCorrect: false },
    ],
  },
];

async function main() {
  console.log("Seeding placeholder questions (DO NOT USE IN PRODUCTION) …");
  for (const q of placeholders) {
    await prisma.question.create({
      data: {
        stem: q.stem,
        subject: q.subject,
        difficulty: q.difficulty,
        explanation: q.explanation,
        source: q.source,
        published: true,
        options: { create: q.options },
      },
    });
  }
  console.log(`✔ Inserted ${placeholders.length} placeholder questions.`);
  console.log("⚠ These are placeholders. Replace or delete them before launch.");
}

main().catch(e => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
