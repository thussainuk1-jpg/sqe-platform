#!/usr/bin/env node
// Usage:
//   node scripts/create-admin.mjs <email> [<password>] [<name>]
// If user exists, promotes to ADMIN. Otherwise creates a new ADMIN account.

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const [email, password, name] = process.argv.slice(2);
  if (!email) {
    console.error("Usage: node scripts/create-admin.mjs <email> [<password>] [<name>]");
    process.exit(1);
  }

  const lower = email.toLowerCase().trim();
  const existing = await prisma.user.findUnique({ where: { email: lower } });

  if (existing) {
    await prisma.user.update({ where: { id: existing.id }, data: { role: "ADMIN" } });
    console.log(`✔ Promoted ${lower} to ADMIN`);
  } else {
    if (!password) {
      console.error("This email isn't registered. Please pass a password to create a new admin:");
      console.error("  node scripts/create-admin.mjs admin@example.com MyStrongPassword123 'Admin'");
      process.exit(1);
    }
    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.user.create({
      data: { email: lower, name: name ?? "Admin", passwordHash, role: "ADMIN" },
    });
    console.log(`✔ Created new ADMIN account: ${lower}`);
  }
}

main().catch(e => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
