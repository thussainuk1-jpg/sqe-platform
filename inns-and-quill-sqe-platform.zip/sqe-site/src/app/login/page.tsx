"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const sp = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await signIn("credentials", { redirect: false, email, password });
    setLoading(false);
    if (res?.error) {
      setError("Wrong email or password");
      return;
    }
    router.push(sp.get("callbackUrl") || "/practice");
    router.refresh();
  }

  return (
    <div className="max-w-md mx-auto px-6 py-20">
      <div className="text-xs uppercase tracking-[0.2em] text-brass mb-2">Sign in</div>
      <h1 className="font-serif text-4xl text-ink mb-8">Welcome back.</h1>
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="label">Email</label>
          <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className="input" />
        </div>
        <div>
          <label className="label">Password</label>
          <input type="password" required value={password} onChange={e => setPassword(e.target.value)} className="input" />
        </div>
        {error && <div className="text-sm text-oxblood">{error}</div>}
        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>
      <p className="text-sm text-ink/60 mt-6">
        Don&rsquo;t have an account? <Link href="/signup" className="text-oxblood underline">Create one</Link>
      </p>
    </div>
  );
}
