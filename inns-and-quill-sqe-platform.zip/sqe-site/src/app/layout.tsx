import "./globals.css";
import type { Metadata } from "next";
import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import SignOutButton from "@/components/SignOutButton";
import Providers from "@/components/Providers";

export const metadata: Metadata = {
  title: "Inns & Quill — SQE1 Practice",
  description: "A practice library for SQE1 candidates. Free to use, donation supported.",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  const role = (session?.user as any)?.role;
  return (
    <html lang="en">
      <body>
        <Providers>
          <header className="border-b border-rule/60 bg-parchment">
            <div className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
              <Link href="/" className="flex items-center gap-3">
                <span className="text-2xl font-serif font-semibold text-ink">Inns &amp; Quill</span>
                <span className="hidden sm:inline text-xs uppercase tracking-[0.2em] text-brass border-l border-rule pl-3">
                  SQE1 Practice
                </span>
              </Link>
              <nav className="flex items-center gap-1 sm:gap-2 text-sm">
                <Link href="/practice" className="px-3 py-2 hover:text-oxblood">Practice</Link>
                <Link href="/mock" className="px-3 py-2 hover:text-oxblood">Mocks</Link>
                <Link href="/donate" className="px-3 py-2 hover:text-oxblood">Donate</Link>
                {role === "ADMIN" && (
                  <Link href="/admin" className="px-3 py-2 text-brass hover:text-oxblood">Admin</Link>
                )}
                {session ? (
                  <>
                    <Link href="/me" className="px-3 py-2 hover:text-oxblood">My progress</Link>
                    <SignOutButton />
                  </>
                ) : (
                  <>
                    <Link href="/login" className="px-3 py-2 hover:text-oxblood">Sign in</Link>
                    <Link href="/signup" className="btn-primary text-xs ml-1">Get started</Link>
                  </>
                )}
              </nav>
            </div>
          </header>

          <main>{children}</main>

          <footer className="border-t border-rule/60 mt-24 bg-cream">
            <div className="max-w-6xl mx-auto px-6 py-10 grid sm:grid-cols-3 gap-6 text-sm text-ink/70">
              <div>
                <div className="font-serif text-xl text-ink mb-2">Inns &amp; Quill</div>
                <p>A practice library for SQE1 candidates. Free to use, supported by reader donations.</p>
              </div>
              <div>
                <div className="font-medium text-ink mb-2">Site</div>
                <ul className="space-y-1">
                  <li><Link href="/practice">Practice</Link></li>
                  <li><Link href="/mock">Mocks</Link></li>
                  <li><Link href="/donate">Donate</Link></li>
                </ul>
              </div>
              <div>
                <div className="font-medium text-ink mb-2">Legal</div>
                <ul className="space-y-1">
                  <li><Link href="/about">About &amp; disclaimer</Link></li>
                  <li><Link href="/privacy">Privacy</Link></li>
                  <li><Link href="/terms">Terms</Link></li>
                </ul>
              </div>
            </div>
            <div className="border-t border-rule/60 py-4 text-center text-xs text-ink/50">
              © {new Date().getFullYear()} Inns &amp; Quill. Not affiliated with the SRA. Practice content is educational only.
            </div>
          </footer>
        </Providers>
      </body>
    </html>
  );
}
