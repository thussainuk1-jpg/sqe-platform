"use client";
import { useState } from "react";

const PRESETS = [3, 10, 30, 100];

export default function DonatePage() {
  const [amount, setAmount] = useState(10);
  const [loading, setLoading] = useState(false);

  async function donate() {
    setLoading(true);
    const res = await fetch("/api/donate/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount }),
    });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      alert(j.error || "Could not start donation");
      setLoading(false);
      return;
    }
    const { url } = await res.json();
    window.location.href = url;
  }

  return (
    <div className="max-w-2xl mx-auto px-6 py-20">
      <div className="text-xs uppercase tracking-[0.25em] text-brass mb-3">Support the library</div>
      <h1 className="font-serif text-5xl text-ink mb-6">Help keep this free.</h1>
      <p className="text-ink/75 leading-relaxed mb-10">
        Inns &amp; Quill is funded entirely by readers. There&rsquo;s no paywall, no subscription, no trial.
        If the practice library has helped you, you can chip in to keep it free for the next candidate.
      </p>

      <div className="card mb-6">
        <div className="text-xs uppercase tracking-wider text-ink/50 mb-3">Choose an amount</div>
        <div className="grid grid-cols-4 gap-2 mb-4">
          {PRESETS.map(v => (
            <button
              key={v}
              onClick={() => setAmount(v)}
              className={`py-3 border ${amount === v ? "border-ink bg-ink text-parchment" : "border-rule bg-parchment hover:border-ink"}`}
            >
              <span className="font-serif text-2xl">£{v}</span>
            </button>
          ))}
        </div>
        <label className="label">Or enter a custom amount (£)</label>
        <input
          type="number"
          min={1}
          max={5000}
          value={amount}
          onChange={e => setAmount(Math.max(1, Number(e.target.value)))}
          className="input"
        />
      </div>

      <button onClick={donate} disabled={loading} className="btn-brass w-full">
        {loading ? "Opening checkout…" : `Donate £${amount}`}
      </button>

      <p className="text-xs text-ink/50 mt-6 text-center">
        Payments are processed securely by Stripe. We don&rsquo;t store your card details.
      </p>
    </div>
  );
}
