import Link from "next/link";

export default function DonateThanks() {
  return (
    <div className="max-w-xl mx-auto px-6 py-24 text-center">
      <div className="text-xs uppercase tracking-[0.25em] text-brass mb-3">Thank you</div>
      <h1 className="font-serif text-5xl text-ink mb-4">Your support means everything.</h1>
      <p className="text-ink/75 leading-relaxed mb-8">
        Your donation directly funds the next batch of questions, the next mock paper,
        and keeps this library free for the next candidate after you.
      </p>
      <Link href="/practice" className="btn-primary">Back to practice</Link>
    </div>
  );
}
