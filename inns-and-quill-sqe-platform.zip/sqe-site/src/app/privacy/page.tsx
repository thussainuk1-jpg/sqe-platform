export const metadata = { title: "Privacy — Inns & Quill" };

export default function PrivacyPage() {
  return (
    <div className="max-w-2xl mx-auto px-6 py-16">
      <div className="text-xs uppercase tracking-[0.25em] text-brass mb-3">Privacy</div>
      <h1 className="font-serif text-5xl text-ink mb-8">Privacy notice.</h1>

      <div className="space-y-5 text-ink/80 leading-relaxed">
        <p className="text-sm italic text-ink/60">
          Last updated: {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}.
          This notice is a plain-English summary, not a substitute for tailored legal advice.
        </p>

        <h2 className="font-serif text-2xl text-ink">What we collect</h2>
        <ul className="list-disc pl-5 space-y-1">
          <li>Your email and (optional) name when you sign up.</li>
          <li>Your password, stored only as a salted bcrypt hash.</li>
          <li>The questions you answer and which option you picked, so we can show your progress.</li>
          <li>If you donate: the donation amount and a Stripe session reference. We never see your card details — Stripe handles those.</li>
        </ul>

        <h2 className="font-serif text-2xl text-ink">Why we collect it</h2>
        <ul className="list-disc pl-5 space-y-1">
          <li>To let you sign in and use the site (contractual basis).</li>
          <li>To show you your own practice history (contractual basis).</li>
          <li>To process donations through Stripe (contractual / legitimate interest).</li>
        </ul>

        <h2 className="font-serif text-2xl text-ink">Who we share it with</h2>
        <p>
          We share only what is necessary with: our hosting provider (Vercel), our database provider (Neon),
          and Stripe (for donations). We do not sell or share your data with advertisers.
        </p>

        <h2 className="font-serif text-2xl text-ink">Your rights</h2>
        <p>
          You can request access, correction, or deletion of your data at any time by emailing us.
          You can also complain to the UK Information Commissioner&rsquo;s Office (ICO) if you believe we&rsquo;ve mishandled your data.
        </p>

        <h2 className="font-serif text-2xl text-ink">Cookies</h2>
        <p>
          We only use a single &ldquo;session&rdquo; cookie to keep you signed in. We do not use analytics or tracking cookies.
        </p>
      </div>
    </div>
  );
}
