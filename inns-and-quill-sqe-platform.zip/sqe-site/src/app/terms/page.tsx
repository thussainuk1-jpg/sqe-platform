export const metadata = { title: "Terms — Inns & Quill" };

export default function TermsPage() {
  return (
    <div className="max-w-2xl mx-auto px-6 py-16">
      <div className="text-xs uppercase tracking-[0.25em] text-brass mb-3">Terms of use</div>
      <h1 className="font-serif text-5xl text-ink mb-8">Terms of use.</h1>

      <div className="space-y-5 text-ink/80 leading-relaxed">
        <p className="text-sm italic text-ink/60">
          Last updated: {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}.
        </p>

        <h2 className="font-serif text-2xl text-ink">Use of the site</h2>
        <p>
          Inns &amp; Quill is free for personal exam-practice use. You may not scrape, copy, redistribute, or republish
          our questions, explanations, or other content without permission. The content is provided for educational
          purposes only and is not legal advice.
        </p>

        <h2 className="font-serif text-2xl text-ink">Accounts</h2>
        <p>
          You are responsible for keeping your password safe and for the activity on your account.
          Please don&rsquo;t share accounts. We may suspend accounts that breach these terms.
        </p>

        <h2 className="font-serif text-2xl text-ink">Donations</h2>
        <p>
          Donations are voluntary and non-refundable except where required by law. They do not give you any
          additional rights, content, or special access on the site. The site is free for everyone, regardless
          of whether they donate.
        </p>

        <h2 className="font-serif text-2xl text-ink">Disclaimer</h2>
        <p>
          Practising on Inns &amp; Quill is not a guarantee of passing the SQE. We make no warranty that our
          content matches the live SRA assessment. To the extent permitted by law, we are not liable for any loss
          arising from your use of the site or reliance on its content.
        </p>

        <h2 className="font-serif text-2xl text-ink">Governing law</h2>
        <p>
          These terms are governed by the laws of England and Wales. Any disputes are subject to the exclusive
          jurisdiction of the courts of England and Wales.
        </p>
      </div>
    </div>
  );
}
