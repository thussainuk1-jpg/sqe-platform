import Link from "next/link";

export const metadata = { title: "About — Inns & Quill" };

export default function AboutPage() {
  return (
    <div className="max-w-2xl mx-auto px-6 py-16 prose-ink">
      <div className="text-xs uppercase tracking-[0.25em] text-brass mb-3">About</div>
      <h1 className="font-serif text-5xl text-ink mb-8">A practice library, not a course.</h1>

      <div className="space-y-5 text-ink/80 leading-relaxed">
        <p>
          Inns &amp; Quill is a small, independent practice library for candidates preparing for the SQE1 functioning legal knowledge papers.
          It is free to use. There is no paywall, no &ldquo;trial&rdquo;, no upsell. If it helps you, you can donate.
          If it doesn&rsquo;t, you don&rsquo;t owe anyone anything.
        </p>

        <p>
          Every question in the bank is written and reviewed by qualified lawyers. We do not generate questions
          with AI. We do not scrape from other providers. The goal is quality over quantity — and honesty about the difference.
        </p>

        <h2 className="font-serif text-2xl text-ink mt-10 mb-3">A note on what this isn&rsquo;t</h2>
        <p>
          Inns &amp; Quill is not affiliated with the Solicitors Regulation Authority (SRA), Kaplan, or any official
          SQE assessment body. We do not predict what will be on the real exam. Practising here is not a guarantee
          of passing the SQE.
        </p>

        <h2 className="font-serif text-2xl text-ink mt-10 mb-3">Educational purpose only</h2>
        <p>
          The questions, model answers, and explanations on this site are educational materials for exam practice.
          They are not legal advice. If you need legal advice about your own situation, please consult a qualified
          solicitor or barrister.
        </p>

        <h2 className="font-serif text-2xl text-ink mt-10 mb-3">Who runs it</h2>
        <p>
          Inns &amp; Quill is run by Tuqeer Hussain, a Solicitor of the Senior Courts of England and Wales
          (SRA No. 7172164), with help from a small group of volunteer reviewers. If you spot an error in a question
          or explanation, please write in — we&rsquo;ll fix it.
        </p>
      </div>

      <div className="mt-12 pt-8 border-t border-rule/60">
        <Link href="/practice" className="btn-primary">Start practising</Link>
      </div>
    </div>
  );
}
