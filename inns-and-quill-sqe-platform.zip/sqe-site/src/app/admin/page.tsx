import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-guard";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function AdminHome() {
  await requireAdmin();
  const [users, qPublished, qDraft, mocks, attempts, donationsAgg] = await Promise.all([
    prisma.user.count(),
    prisma.question.count({ where: { published: true } }),
    prisma.question.count({ where: { published: false } }),
    prisma.mock.count(),
    prisma.attempt.count(),
    prisma.donation.aggregate({ _sum: { amountPence: true }, where: { status: "succeeded" } }),
  ]);
  const donatedGBP = ((donationsAgg._sum.amountPence ?? 0) / 100).toFixed(2);

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="flex justify-between items-baseline mb-10">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-brass mb-2">Admin</div>
          <h1 className="font-serif text-4xl text-ink">Dashboard</h1>
        </div>
        <nav className="flex gap-2 text-sm">
          <Link href="/admin/questions" className="btn-ghost">Questions</Link>
          <Link href="/admin/mocks" className="btn-ghost">Mocks</Link>
          <Link href="/admin/questions/new" className="btn-primary">+ New question</Link>
        </nav>
      </div>

      <div className="grid sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <Stat label="Users" value={users} />
        <Stat label="Published" value={qPublished} />
        <Stat label="Drafts" value={qDraft} />
        <Stat label="Mocks" value={mocks} />
        <Stat label="Attempts" value={attempts} />
        <Stat label="Donated (£)" value={donatedGBP} />
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: any }) {
  return (
    <div className="card">
      <div className="text-xs uppercase tracking-wider text-ink/50 mb-2">{label}</div>
      <div className="font-serif text-3xl text-ink">{value}</div>
    </div>
  );
}
