import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-guard";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function AdminMocks() {
  await requireAdmin();
  const mocks = await prisma.mock.findMany({
    include: { _count: { select: { items: true } } },
    orderBy: { createdAt: "desc" },
  });
  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="flex justify-between items-baseline mb-8">
        <h1 className="font-serif text-4xl text-ink">Mocks</h1>
        <div className="flex gap-2">
          <Link href="/admin" className="btn-ghost text-xs">← Dashboard</Link>
          <Link href="/admin/mocks/new" className="btn-primary text-xs">+ New mock</Link>
        </div>
      </div>

      {mocks.length === 0 && (
        <div className="card text-center text-ink/60">No mocks yet.</div>
      )}

      <div className="space-y-2">
        {mocks.map(m => (
          <Link key={m.id} href={`/admin/mocks/${m.id}`} className="card hover:border-ink block">
            <div className="flex justify-between items-baseline">
              <h3 className="font-serif text-xl text-ink">{m.title}</h3>
              <span className={`text-xs px-2 py-1 ${m.published ? "bg-forest/10 text-forest" : "bg-rule/40 text-ink/60"}`}>
                {m.published ? "Published" : "Draft"}
              </span>
            </div>
            <div className="text-xs text-ink/60 mt-2">{m._count.items} questions · {m.durationMins} mins</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
