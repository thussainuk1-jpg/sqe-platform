"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewMock() {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [durationMins, setDurationMins] = useState(170);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    const res = await fetch("/api/admin/mocks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, description, durationMins }),
    });
    setSaving(false);
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      setError(j.error || "Save failed");
      return;
    }
    const j = await res.json();
    router.push(`/admin/mocks/${j.id}`);
  }

  return (
    <div className="max-w-2xl mx-auto px-6 py-12">
      <div className="text-xs uppercase tracking-[0.2em] text-brass mb-2">Admin · New</div>
      <h1 className="font-serif text-4xl text-ink mb-8">New mock paper</h1>
      <form onSubmit={save} className="space-y-4">
        <div>
          <label className="label">Title</label>
          <input value={title} onChange={e => setTitle(e.target.value)} required className="input" />
        </div>
        <div>
          <label className="label">Description</label>
          <textarea value={description} onChange={e => setDescription(e.target.value)} className="input" />
        </div>
        <div>
          <label className="label">Duration (minutes)</label>
          <input type="number" min={10} max={300} value={durationMins} onChange={e => setDurationMins(Number(e.target.value))} className="input" />
        </div>
        {error && <div className="text-sm text-oxblood">{error}</div>}
        <button type="submit" disabled={saving} className="btn-primary">
          {saving ? "Creating…" : "Create mock"}
        </button>
      </form>
    </div>
  );
}
