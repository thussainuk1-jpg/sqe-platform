"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { SUBJECT_LABELS } from "@/lib/subjects";

type Item = { id: string; position: number; questionId: string; stem: string; subject: string };
type Avail = { id: string; stem: string; subject: string };

export default function MockEditor({ mock, available }: { mock: any; available: Avail[] }) {
  const router = useRouter();
  const [title, setTitle] = useState(mock.title);
  const [description, setDescription] = useState(mock.description);
  const [durationMins, setDurationMins] = useState(mock.durationMins);
  const [published, setPublished] = useState(mock.published);
  const [filter, setFilter] = useState("");
  const [busy, setBusy] = useState(false);

  async function saveMeta() {
    setBusy(true);
    await fetch(`/api/admin/mocks/${mock.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, description, durationMins, published }),
    });
    setBusy(false);
    router.refresh();
  }

  async function addQuestion(qid: string) {
    await fetch(`/api/admin/mocks/${mock.id}/items`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questionId: qid }),
    });
    router.refresh();
  }

  async function removeItem(itemId: string) {
    await fetch(`/api/admin/mocks/${mock.id}/items/${itemId}`, { method: "DELETE" });
    router.refresh();
  }

  async function remove() {
    if (!confirm("Delete this mock entirely?")) return;
    await fetch(`/api/admin/mocks/${mock.id}`, { method: "DELETE" });
    router.push("/admin/mocks");
  }

  const filtered = filter
    ? available.filter(q => q.stem.toLowerCase().includes(filter.toLowerCase()))
    : available;

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="flex justify-between items-baseline mb-8">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-brass mb-2">Admin · Edit mock</div>
          <h1 className="font-serif text-4xl text-ink">{mock.title}</h1>
        </div>
        <button onClick={remove} className="btn-ghost text-oxblood border-oxblood/30">Delete mock</button>
      </div>

      <div className="grid md:grid-cols-12 gap-8">
        {/* Metadata */}
        <div className="md:col-span-5 space-y-4">
          <div className="card space-y-4">
            <div>
              <label className="label">Title</label>
              <input value={title} onChange={e => setTitle(e.target.value)} className="input" />
            </div>
            <div>
              <label className="label">Description</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} className="input" />
            </div>
            <div>
              <label className="label">Duration (mins)</label>
              <input type="number" value={durationMins} onChange={e => setDurationMins(Number(e.target.value))} className="input" />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={published} onChange={e => setPublished(e.target.checked)} />
              <span>Published</span>
            </label>
            <button onClick={saveMeta} disabled={busy} className="btn-primary w-full">
              {busy ? "Saving…" : "Save settings"}
            </button>
          </div>

          <div className="card">
            <h3 className="font-serif text-xl mb-3">Questions in this mock ({mock.items.length})</h3>
            {mock.items.length === 0 && <p className="text-sm text-ink/60">No questions yet. Add some from the right.</p>}
            <ol className="space-y-1">
              {mock.items.map((it: Item) => (
                <li key={it.id} className="flex items-start gap-3 p-2 border border-rule/40 bg-parchment">
                  <span className="font-serif text-brass w-6 shrink-0">{it.position}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-ink truncate">{it.stem.slice(0, 90)}…</div>
                    <div className="text-xs text-ink/60">{SUBJECT_LABELS[it.subject] ?? it.subject}</div>
                  </div>
                  <button onClick={() => removeItem(it.id)} className="text-xs text-oxblood">Remove</button>
                </li>
              ))}
            </ol>
          </div>
        </div>

        {/* Available questions */}
        <div className="md:col-span-7">
          <div className="card">
            <h3 className="font-serif text-xl mb-3">Add published questions</h3>
            <input
              placeholder="Search by stem…"
              value={filter}
              onChange={e => setFilter(e.target.value)}
              className="input mb-4"
            />
            {filtered.length === 0 && <p className="text-sm text-ink/60">No matching available questions.</p>}
            <div className="space-y-1 max-h-[600px] overflow-y-auto">
              {filtered.map(q => (
                <button
                  key={q.id}
                  onClick={() => addQuestion(q.id)}
                  className="w-full text-left p-2 border border-rule/40 hover:border-ink bg-parchment flex items-start gap-3"
                >
                  <span className="text-brass text-lg shrink-0">+</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-ink truncate">{q.stem.slice(0, 110)}…</div>
                    <div className="text-xs text-ink/60">{SUBJECT_LABELS[q.subject] ?? q.subject}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
