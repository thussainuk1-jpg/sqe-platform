import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-guard";
import { notFound } from "next/navigation";
import MockEditor from "./editor";

export default async function AdminMockEdit({ params }: { params: { id: string } }) {
  await requireAdmin();
  const [mock, allQuestions] = await Promise.all([
    prisma.mock.findUnique({
      where: { id: params.id },
      include: {
        items: { orderBy: { position: "asc" }, include: { question: { select: { id: true, stem: true, subject: true } } } },
      },
    }),
    prisma.question.findMany({
      where: { published: true },
      orderBy: { updatedAt: "desc" },
      select: { id: true, stem: true, subject: true },
      take: 500,
    }),
  ]);
  if (!mock) notFound();
  const used = new Set(mock.items.map(it => it.questionId));
  const available = allQuestions.filter(q => !used.has(q.id));
  return (
    <MockEditor
      mock={{
        id: mock.id,
        title: mock.title,
        description: mock.description ?? "",
        durationMins: mock.durationMins,
        published: mock.published,
        items: mock.items.map(it => ({ id: it.id, position: it.position, questionId: it.questionId, stem: it.question.stem, subject: it.question.subject })),
      }}
      available={available}
    />
  );
}
