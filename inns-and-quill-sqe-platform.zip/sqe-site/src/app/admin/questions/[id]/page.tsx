import { requireAdmin } from "@/lib/admin-guard";
import { prisma } from "@/lib/db";
import { notFound } from "next/navigation";
import QuestionForm from "../QuestionForm";

export default async function EditQuestion({ params }: { params: { id: string } }) {
  await requireAdmin();
  const q = await prisma.question.findUnique({
    where: { id: params.id },
    include: { options: { orderBy: { label: "asc" } } },
  });
  if (!q) notFound();
  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <div className="text-xs uppercase tracking-[0.2em] text-brass mb-2">Admin · Edit</div>
      <h1 className="font-serif text-4xl text-ink mb-8">Edit question</h1>
      <QuestionForm
        initial={{
          id: q.id,
          stem: q.stem,
          subject: q.subject,
          difficulty: q.difficulty,
          explanation: q.explanation,
          source: q.source ?? "",
          published: q.published,
          options: q.options.map(o => ({ label: o.label, text: o.text, isCorrect: o.isCorrect })),
        }}
      />
    </div>
  );
}
