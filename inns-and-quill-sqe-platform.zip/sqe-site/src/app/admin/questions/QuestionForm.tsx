"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { SUBJECT_LABELS } from "@/lib/subjects";

type Option = { label: string; text: string; isCorrect: boolean };
type Initial = {
  id?: string;
  stem: string;
  subject: string;
  difficulty: string;
  explanation: string;
  source: string;
  published: boolean;
  options: Option[];
};

const DEFAULT_OPTIONS: Option[] = [
  { label: "A", text: "", isCorrect: false },
  { label: "B", text: "", isCorrect: false },
  { label: "C", text: "", isCorrect: false },
  { label: "D", text: "", isCorrect: false },
  { label: "E", text: "", isCorrect: false },
];

export default function QuestionForm({ initial }: { initial?: Initial }) {
  const router = useRouter();
  const [stem, setStem] = useState(initial?.stem ?? "");
  const [subject, setSubject] = useState(initial?.subject ?? "CONTRACT");
  const [difficulty, setDifficulty] = useState(initial?.difficulty ?? "MEDIUM");
  const [explanation, setExplanation] = useState(initial?.explanation ?? "");
  const [source, setSource] = useState(initial?.source ?? "");
  const [published, setPublished] = useState(initial?.published ?? false);
  const [options, setOptions] = useState<Option[]>(initial?.options?.length ? initial.options : DEFAULT_OPTIONS);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  function setOption(i: number, patch: Partial<Option>) {
    setOptions(opts => opts.map((o, idx) => idx === i ? { ...o, ...patch } : o));
  }
  function markCorrect(i: number) {
    setOptions(opts => opts.map((o, idx) => ({ ...o, isCorrect: idx === i })));
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!options.some(o => o.isCorrect)) {
      setError("Mark one option as correct.");
      return;
    }
    if (options.filter(o => o.text.trim()).length < 2) {
      setError("Provide at least 2 options.");
      return;
    }
    setSaving(true);
    const body = { stem, subject, difficulty, explanation, source, published, options: options.filter(o => o.text.trim()) };
    const url = initial?.id ? `/api/admin/questions/${initial.id}` : "/api/admin/questions";
    const method = initial?.id ? "PUT" : "POST";
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    setSaving(false);
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      setError(j.error || "Save failed");
      return;
    }
    const j = await res.json();
    router.push(`/admin/questions/${j.id}`);
    router.refresh();
  }

  async function remove() {
    if (!initial?.id) return;
    if (!confirm("Delete this question? All attempts referencing it will also be removed.")) return;
    const res = await fetch(`/api/admin/questions/${initial.id}`, { method: "DELETE" });
    if (res.ok) {
      router.push("/admin/questions");
      router.refresh();
    }
  }

  return (
    <form onSubmit={save} className="space-y-6">
      <div>
        <label className="label">Stem (the question)</label>
        <textarea required value={stem} onChange={e => setStem(e.target.value)} className="input min-h-[140px] font-serif" />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="label">Subject</label>
          <select value={subject} onChange={e => setSubject(e.target.value)} className="input">
            {Object.entries(SUBJECT_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Difficulty</label>
          <select value={difficulty} onChange={e => setDifficulty(e.target.value)} className="input">
            <option value="EASY">Easy</option>
            <option value="MEDIUM">Medium</option>
            <option value="HARD">Hard</option>
          </select>
        </div>
      </div>

      <div>
        <div className="flex items-baseline justify-between mb-2">
          <span className="label !mb-0">Options</span>
          <span className="text-xs text-ink/50">Select the radio next to the correct answer</span>
        </div>
        <div className="space-y-2">
          {options.map((opt, i) => (
            <div key={i} className="flex items-start gap-3 border border-rule/60 p-3 bg-cream">
              <input
                type="radio"
                name="correct"
                checked={opt.isCorrect}
                onChange={() => markCorrect(i)}
                className="mt-2"
              />
              <span className="font-serif text-xl text-brass w-6 shrink-0 pt-1">{opt.label}</span>
              <input
                value={opt.text}
                onChange={e => setOption(i, { text: e.target.value })}
                placeholder={`Option ${opt.label} text`}
                className="input"
              />
            </div>
          ))}
        </div>
      </div>

      <div>
        <label className="label">Model explanation</label>
        <textarea required value={explanation} onChange={e => setExplanation(e.target.value)} className="input min-h-[140px]" />
      </div>

      <div>
        <label className="label">Source / SRA spec reference (optional)</label>
        <input value={source} onChange={e => setSource(e.target.value)} className="input" />
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={published} onChange={e => setPublished(e.target.checked)} />
        <span>Publish (visible to students)</span>
      </label>

      {error && <div className="text-sm text-oxblood">{error}</div>}

      <div className="flex gap-3 pt-4 border-t border-rule/60">
        <button type="submit" disabled={saving} className="btn-primary">
          {saving ? "Saving…" : initial?.id ? "Save changes" : "Create question"}
        </button>
        {initial?.id && (
          <button type="button" onClick={remove} className="btn-ghost text-oxblood border-oxblood/30 ml-auto">
            Delete
          </button>
        )}
      </div>
    </form>
  );
}
