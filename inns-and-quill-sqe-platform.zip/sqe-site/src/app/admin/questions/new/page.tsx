import { requireAdmin } from "@/lib/admin-guard";
import QuestionForm from "../QuestionForm";

export default async function NewQuestionPage() {
  await requireAdmin();
  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <div className="text-xs uppercase tracking-[0.2em] text-brass mb-2">Admin · New</div>
      <h1 className="font-serif text-4xl text-ink mb-8">New question</h1>
      <QuestionForm />
    </div>
  );
}
