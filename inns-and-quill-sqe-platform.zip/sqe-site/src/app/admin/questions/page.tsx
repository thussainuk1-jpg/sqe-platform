import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-guard";
import { SUBJECT_LABELS } from "@/lib/subjects";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function QuestionList() {
  await requireAdmin();
  const questions = await prisma.question.findMany({
    orderBy: { updatedAt: "desc" },
    take: 200,
  });

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="flex justify-between items-baseline mb-8">
        <h1 className="font-serif text-4xl text-ink">Questions</h1>
        <div className="flex gap-2">
          <Link href="/admin" className="btn-ghost text-xs">← Dashboard</Link>
          <Link href="/admin/questions/new" className="btn-primary text-xs">+ New question</Link>
        </div>
      </div>

      {questions.length === 0 && (
        <div className="card text-center text-ink/60">
          No questions yet. <Link href="/admin/questions/new" className="text-oxblood underline">Create your first one</Link>.
        </div>
      )}

      <div className="space-y-2">
        {questions.map(q => (
          <Link
            key={q.id}
            href={`/admin/questions/${q.id}`}
            className="card flex items-center gap-4 hover:border-ink"
          >
            <div className="flex-1 min-w-0">
              <div className="text-sm text-ink truncate">{q.stem.slice(0, 140)}…</div>
              <div className="text-xs text-ink/60 mt-1">
                {SUBJECT_LABELS[q.subject] ?? q.subject} · {q.difficulty}
              </div>
            </div>
            <span className={`text-xs px-2 py-1 ${q.published ? "bg-forest/10 text-forest" : "bg-rule/40 text-ink/60"}`}>
              {q.published ? "Published" : "Draft"}
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
