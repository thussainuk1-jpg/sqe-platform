"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function SignupPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await fetch("/api/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      setError(j.error || "Something went wrong");
      setLoading(false);
      return;
    }
    await signIn("credentials", { redirect: false, email, password });
    setLoading(false);
    router.push("/practice");
    router.refresh();
  }

  return (
    <div className="max-w-md mx-auto px-6 py-20">
      <div className="text-xs uppercase tracking-[0.2em] text-brass mb-2">Create account</div>
      <h1 className="font-serif text-4xl text-ink mb-8">Start practising.</h1>
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="label">Name</label>
          <input value={name} onChange={e => setName(e.target.value)} className="input" required />
        </div>
        <div>
          <label className="label">Email</label>
          <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className="input" />
        </div>
        <div>
          <label className="label">Password (8+ chars)</label>
          <input type="password" required minLength={8} value={password} onChange={e => setPassword(e.target.value)} className="input" />
        </div>
        {error && <div className="text-sm text-oxblood">{error}</div>}
        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? "Creating account…" : "Create account"}
        </button>
      </form>
      <p className="text-sm text-ink/60 mt-6">
        Already have an account? <Link href="/login" className="text-oxblood underline">Sign in</Link>
      </p>
    </div>
  );
}
