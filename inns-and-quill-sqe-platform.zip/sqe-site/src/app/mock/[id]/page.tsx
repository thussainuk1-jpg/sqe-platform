import { prisma } from "@/lib/db";
import { notFound } from "next/navigation";
import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export default async function MockDetail({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  const mock = await prisma.mock.findUnique({
    where: { id: params.id },
    include: { _count: { select: { items: true } } },
  });
  if (!mock || !mock.published) notFound();

  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <Link href="/mock" className="text-sm text-ink/60 hover:text-oxblood">← All mocks</Link>
      <div className="text-xs uppercase tracking-[0.25em] text-brass mt-8 mb-3">Timed Mock</div>
      <h1 className="font-serif text-5xl text-ink mb-6">{mock.title}</h1>
      {mock.description && <p className="text-ink/70 leading-relaxed mb-8">{mock.description}</p>}

      <div className="card grid grid-cols-2 gap-6 mb-8">
        <Stat label="Questions" value={mock._count.items.toString()} />
        <Stat label="Duration" value={`${mock.durationMins} mins`} />
      </div>

      <div className="card mb-8">
        <h3 className="font-serif text-xl mb-3">Before you start</h3>
        <ul className="text-sm text-ink/75 space-y-2 list-disc list-inside">
          <li>You will not be able to pause once you begin.</li>
          <li>Your session is saved as you go — closing the tab won&rsquo;t lose your answers.</li>
          <li>The clock runs in real time and the test auto-submits at zero.</li>
          <li>You&rsquo;ll see your full breakdown only after submission.</li>
        </ul>
      </div>

      {session?.user ? (
        <form action={`/api/mock/${mock.id}/start`} method="post">
          <button className="btn-primary w-full">Begin mock</button>
        </form>
      ) : (
        <Link href={`/login?callbackUrl=/mock/${mock.id}`} className="btn-primary w-full">
          Sign in to begin
        </Link>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-wider text-ink/50 mb-1">{label}</div>
      <div className="font-serif text-3xl text-ink">{value}</div>
    </div>
  );
}
