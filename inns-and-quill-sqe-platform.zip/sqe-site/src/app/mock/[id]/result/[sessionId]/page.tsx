import { prisma } from "@/lib/db";
import { notFound } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { SUBJECT_LABELS } from "@/lib/subjects";
import Link from "next/link";

export default async function MockResult({ params }: { params: { id: string; sessionId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) notFound();
  const userId = (session.user as any).id as string;

  const ms = await prisma.mockSession.findUnique({
    where: { id: params.sessionId },
    include: {
      mock: true,
      attempts: { include: { question: true } },
    },
  });
  if (!ms || ms.userId !== userId) notFound();

  const total = ms.total;
  const correct = ms.score ?? 0;
  const pct = total > 0 ? Math.round((correct / total) * 100) : 0;

  // Subject breakdown
  const bySubject: Record<string, { correct: number; total: number }> = {};
  ms.attempts.forEach(a => {
    const s = a.question.subject;
    if (!bySubject[s]) bySubject[s] = { correct: 0, total: 0 };
    bySubject[s].total += 1;
    if (a.correct) bySubject[s].correct += 1;
  });

  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <div className="text-xs uppercase tracking-[0.25em] text-brass mb-3">Result</div>
      <h1 className="font-serif text-5xl text-ink mb-2">{ms.mock.title}</h1>
      <p className="text-ink/60 mb-12">Submitted {ms.finishedAt?.toLocaleString() ?? ""}</p>

      <div className="card mb-10 text-center">
        <div className="text-xs uppercase tracking-wider text-ink/50 mb-3">Overall</div>
        <div className="font-serif text-7xl text-ink mb-2">{pct}%</div>
        <div className="text-ink/70">{correct} of {total} correct</div>
      </div>

      <h2 className="font-serif text-2xl text-ink mb-4">By subject</h2>
      <div className="space-y-2">
        {Object.entries(bySubject).map(([subj, s]) => {
          const p = Math.round((s.correct / s.total) * 100);
          return (
            <div key={subj} className="card flex items-center gap-6">
              <div className="flex-1">
                <div className="text-sm text-ink mb-2">{SUBJECT_LABELS[subj] ?? subj}</div>
                <div className="h-2 bg-rule/40">
                  <div className={`h-full ${p >= 50 ? "bg-forest" : "bg-oxblood"}`} style={{ width: `${p}%` }} />
                </div>
              </div>
              <div className="text-right text-sm">
                <div className="font-serif text-xl">{p}%</div>
                <div className="text-xs text-ink/60">{s.correct}/{s.total}</div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-12 flex flex-wrap gap-3">
        <Link href="/me" className="btn-primary">View my progress</Link>
        <Link href="/mock" className="btn-ghost">Take another mock</Link>
        <Link href="/donate" className="btn-brass">Support this resource</Link>
      </div>
    </div>
  );
}
