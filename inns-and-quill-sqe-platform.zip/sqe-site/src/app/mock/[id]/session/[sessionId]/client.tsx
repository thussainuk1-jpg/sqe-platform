"use client";
import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";

type Item = {
  questionId: string;
  position: number;
  stem: string;
  options: { id: string; label: string; text: string }[];
};

export default function MockSessionClient({
  sessionId, mockTitle, items, answeredMap, endsAtMs,
}: {
  sessionId: string;
  mockTitle: string;
  items: Item[];
  answeredMap: Record<string, string>;
  endsAtMs: number;
}) {
  const router = useRouter();
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>(answeredMap);
  const [now, setNow] = useState(Date.now());
  const [submitting, setSubmitting] = useState(false);
  const submitOnceRef = useRef(false);

  const current = items[idx];
  const remainingMs = Math.max(0, endsAtMs - now);
  const mins = Math.floor(remainingMs / 60_000);
  const secs = Math.floor((remainingMs % 60_000) / 1000);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const submit = useCallback(async () => {
    if (submitOnceRef.current) return;
    submitOnceRef.current = true;
    setSubmitting(true);
    const res = await fetch(`/api/mock/session/${sessionId}/submit`, { method: "POST" });
    if (res.ok) {
      const j = await res.json();
      router.push(`/mock/${j.mockId}/result/${sessionId}`);
    } else {
      submitOnceRef.current = false;
      setSubmitting(false);
    }
  }, [sessionId, router]);

  // Auto-submit when time runs out
  useEffect(() => {
    if (remainingMs <= 0 && !submitOnceRef.current) submit();
  }, [remainingMs, submit]);

  async function saveAnswer(label: string) {
    setAnswers(prev => ({ ...prev, [current.questionId]: label }));
    await fetch(`/api/mock/session/${sessionId}/answer`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questionId: current.questionId, selectedLabel: label }),
    });
  }

  const answeredCount = Object.keys(answers).length;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Sticky exam header */}
      <div className="sticky top-0 bg-ink text-parchment border-b border-brass/50 z-10">
        <div className="max-w-5xl mx-auto px-6 py-3 flex items-center justify-between text-sm">
          <div>
            <span className="text-brass text-xs uppercase tracking-wider mr-3">Mock</span>
            <span className="font-serif">{mockTitle}</span>
          </div>
          <div className="flex items-center gap-6">
            <span className="text-parchment/70">{answeredCount} / {items.length} answered</span>
            <span className={`font-serif text-xl ${remainingMs < 5 * 60_000 ? "text-oxblood" : "text-parchment"}`}>
              {String(mins).padStart(2, "0")}:{String(secs).padStart(2, "0")}
            </span>
          </div>
        </div>
      </div>

      <div className="flex-1 max-w-5xl w-full mx-auto px-6 py-10 grid md:grid-cols-12 gap-8">
        {/* Question pane */}
        <div className="md:col-span-9">
          <div className="text-xs uppercase tracking-wider text-ink/50 mb-2">
            Question {idx + 1} of {items.length}
          </div>
          <div className="font-serif text-xl text-ink mb-6 whitespace-pre-wrap leading-snug">{current.stem}</div>

          <div className="space-y-2">
            {current.options.map(opt => {
              const sel = answers[current.questionId] === opt.label;
              return (
                <button
                  key={opt.id}
                  onClick={() => saveAnswer(opt.label)}
                  className={`w-full text-left p-4 border flex gap-4 ${
                    sel ? "border-ink bg-ink/5" : "border-rule hover:border-ink/60 bg-parchment"
                  }`}
                >
                  <span className="font-serif text-xl text-brass w-6 shrink-0">{opt.label}</span>
                  <span className="text-ink">{opt.text}</span>
                </button>
              );
            })}
          </div>

          <div className="flex justify-between items-center mt-8">
            <button
              onClick={() => setIdx(Math.max(0, idx - 1))}
              disabled={idx === 0}
              className="btn-ghost disabled:opacity-40"
            >
              ← Previous
            </button>
            {idx < items.length - 1 ? (
              <button onClick={() => setIdx(idx + 1)} className="btn-primary">Next →</button>
            ) : (
              <button onClick={submit} disabled={submitting} className="btn-brass">
                {submitting ? "Submitting…" : "Submit mock"}
              </button>
            )}
          </div>
        </div>

        {/* Navigator */}
        <aside className="md:col-span-3 md:border-l border-rule/60 md:pl-6">
          <div className="text-xs uppercase tracking-wider text-ink/50 mb-3">Navigator</div>
          <div className="grid grid-cols-6 md:grid-cols-5 gap-1.5">
            {items.map((it, i) => {
              const answered = !!answers[it.questionId];
              const isCurrent = i === idx;
              return (
                <button
                  key={it.questionId}
                  onClick={() => setIdx(i)}
                  className={`text-xs h-8 border ${
                    isCurrent ? "border-ink bg-ink text-parchment" :
                    answered ? "border-forest bg-forest/10 text-forest" :
                    "border-rule bg-parchment text-ink/60"
                  }`}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>
          <button onClick={submit} disabled={submitting} className="btn-brass w-full mt-6">
            {submitting ? "Submitting…" : "Submit mock"}
          </button>
        </aside>
      </div>
    </div>
  );
}
