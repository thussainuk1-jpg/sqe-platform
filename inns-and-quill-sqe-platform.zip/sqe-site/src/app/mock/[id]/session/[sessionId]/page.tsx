import { prisma } from "@/lib/db";
import { notFound, redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import MockSessionClient from "./client";

export default async function Page({ params }: { params: { id: string; sessionId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect(`/login?callbackUrl=/mock/${params.id}`);
  const userId = (session.user as any).id as string;

  const ms = await prisma.mockSession.findUnique({
    where: { id: params.sessionId },
    include: {
      mock: {
        include: {
          items: {
            orderBy: { position: "asc" },
            include: {
              question: {
                include: { options: { select: { id: true, label: true, text: true } } },
              },
            },
          },
        },
      },
      attempts: { select: { questionId: true, selectedOption: true } },
    },
  });
  if (!ms || ms.userId !== userId) notFound();

  if (ms.finishedAt) {
    redirect(`/mock/${ms.mockId}/result/${ms.id}`);
  }

  const answeredMap: Record<string, string> = {};
  ms.attempts.forEach(a => { answeredMap[a.questionId] = a.selectedOption; });

  const items = ms.mock.items.map(it => ({
    questionId: it.question.id,
    position: it.position,
    stem: it.question.stem,
    options: it.question.options.sort((a, b) => a.label.localeCompare(b.label)),
  }));

  const endsAtMs = ms.startedAt.getTime() + ms.mock.durationMins * 60_000;

  return (
    <MockSessionClient
      sessionId={ms.id}
      mockTitle={ms.mock.title}
      items={items}
      answeredMap={answeredMap}
      endsAtMs={endsAtMs}
    />
  );
}
