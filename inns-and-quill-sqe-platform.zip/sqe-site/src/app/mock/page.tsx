import Link from "next/link";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function MockListing() {
  const mocks = await prisma.mock.findMany({
    where: { published: true },
    include: { _count: { select: { items: true } } },
    orderBy: { createdAt: "desc" },
  }).catch(() => []);

  return (
    <div className="max-w-5xl mx-auto px-6 py-16">
      <div className="text-xs uppercase tracking-[0.25em] text-brass mb-3">Timed Mocks</div>
      <h1 className="font-serif text-5xl text-ink mb-4">Full mock papers.</h1>
      <p className="text-ink/70 mb-12 max-w-2xl">
        Sit a full SQE1-style paper under timed conditions. You&rsquo;ll see your overall score
        and a subject-by-subject breakdown at the end.
      </p>

      {mocks.length === 0 && (
        <div className="card text-center">
          <p className="text-ink/70 mb-2">No mocks published yet.</p>
          <p className="text-sm text-ink/50">Check back soon — or use Quick Practice in the meantime.</p>
        </div>
      )}

      <div className="grid sm:grid-cols-2 gap-6">
        {mocks.map(m => (
          <Link key={m.id} href={`/mock/${m.id}`} className="card hover:border-ink transition-colors block">
            <h3 className="font-serif text-2xl text-ink mb-2">{m.title}</h3>
            {m.description && <p className="text-sm text-ink/70 mb-4">{m.description}</p>}
            <div className="flex justify-between items-center text-xs text-ink/60 mt-4 pt-4 border-t border-rule/40">
              <span>{m._count.items} questions</span>
              <span>{m.durationMins} mins</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
