"use client";
import { useEffect, useState, useCallback } from "react";
import { useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import Link from "next/link";

type Option = { id: string; label: string; text: string };
type Question = {
  id: string;
  stem: string;
  subject: string;
  subjectLabel: string;
  options: Option[];
};
type ReviewState = {
  selectedLabel: string;
  correctLabel: string;
  correct: boolean;
  explanation: string;
};

export default function PracticePlay() {
  const sp = useSearchParams();
  const subject = sp.get("subject") || "MIXED";
  const { status } = useSession();

  const [q, setQ] = useState<Question | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [review, setReview] = useState<ReviewState | null>(null);
  const [stats, setStats] = useState({ done: 0, correct: 0 });

  const loadNext = useCallback(async () => {
    setLoading(true);
    setSelected(null);
    setReview(null);
    setError(null);
    try {
      const res = await fetch(`/api/practice/next?subject=${subject}`);
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || "Could not load question");
      }
      const data = await res.json();
      setQ(data.question);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [subject]);

  useEffect(() => { loadNext(); }, [loadNext]);

  async function submit() {
    if (!q || !selected) return;
    const res = await fetch("/api/practice/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questionId: q.id, selectedLabel: selected }),
    });
    if (!res.ok) {
      setError("Could not submit answer");
      return;
    }
    const data = await res.json();
    setReview(data);
    setStats(s => ({ done: s.done + 1, correct: s.correct + (data.correct ? 1 : 0) }));
  }

  if (status === "unauthenticated") {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <h1 className="font-serif text-3xl mb-4">Sign in to practise</h1>
        <p className="text-ink/70 mb-6">We track your progress so you can see weak subjects over time.</p>
        <Link href={`/login?callbackUrl=/practice/play?subject=${subject}`} className="btn-primary">Sign in</Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <div className="flex justify-between items-baseline mb-8 pb-4 border-b border-rule/60">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-brass">Practice mode</div>
          <div className="font-serif text-2xl text-ink">{q?.subjectLabel || "Loading…"}</div>
        </div>
        <div className="text-sm text-ink/60 text-right">
          <div>{stats.done} answered</div>
          <div>{stats.correct} correct</div>
        </div>
      </div>

      {loading && <div className="text-ink/60">Loading question…</div>}
      {error && (
        <div className="card text-center">
          <p className="text-oxblood mb-4">{error}</p>
          <Link href="/practice" className="btn-ghost">Back to subjects</Link>
        </div>
      )}

      {!loading && q && (
        <div className="card">
          <div className="text-xs uppercase tracking-wider text-ink/50 mb-3">Question</div>
          <div className="font-serif text-xl text-ink mb-6 leading-snug whitespace-pre-wrap">{q.stem}</div>

          <div className="space-y-2">
            {q.options.map(opt => {
              const isSel = selected === opt.label;
              const isCorrect = review && opt.label === review.correctLabel;
              const isWrongPick = review && isSel && !review.correct;
              return (
                <button
                  key={opt.id}
                  disabled={!!review}
                  onClick={() => setSelected(opt.label)}
                  className={`w-full text-left p-4 border transition-colors flex gap-4 ${
                    isCorrect ? "border-forest bg-forest/5" :
                    isWrongPick ? "border-oxblood bg-oxblood/5" :
                    isSel ? "border-ink bg-ink/5" :
                    "border-rule hover:border-ink/60 bg-parchment"
                  }`}
                >
                  <span className="font-serif text-xl text-brass w-6 shrink-0">{opt.label}</span>
                  <span className="text-ink">{opt.text}</span>
                </button>
              );
            })}
          </div>

          {!review ? (
            <button
              disabled={!selected}
              onClick={submit}
              className="btn-primary mt-6 w-full disabled:opacity-40"
            >
              Submit answer
            </button>
          ) : (
            <>
              <div className={`mt-6 p-4 border-l-4 ${review.correct ? "border-forest bg-forest/5" : "border-oxblood bg-oxblood/5"}`}>
                <div className={`text-xs uppercase tracking-wider mb-2 ${review.correct ? "text-forest" : "text-oxblood"}`}>
                  {review.correct ? "Correct" : `Incorrect — answer was ${review.correctLabel}`}
                </div>
                <div className="text-sm text-ink/80 leading-relaxed whitespace-pre-wrap">{review.explanation}</div>
              </div>
              <button onClick={loadNext} className="btn-primary mt-4 w-full">Next question →</button>
            </>
          )}
        </div>
      )}

      <div className="mt-8 text-center">
        <Link href="/practice" className="text-sm text-ink/60 hover:text-oxblood">← Change subject</Link>
      </div>
    </div>
  );
}
