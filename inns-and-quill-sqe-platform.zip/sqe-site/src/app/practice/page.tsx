import Link from "next/link";
import { prisma } from "@/lib/db";
import { SUBJECT_LABELS } from "@/lib/subjects";

export const dynamic = "force-dynamic";

export default async function PracticeLanding() {
  const counts = await prisma.question.groupBy({
    by: ["subject"],
    where: { published: true },
    _count: { _all: true },
  }).catch(() => []);

  const map = new Map(counts.map((c: any) => [c.subject, c._count._all]));

  return (
    <div className="max-w-6xl mx-auto px-6 py-16">
      <div className="text-xs uppercase tracking-[0.25em] text-brass mb-3">Quick Practice</div>
      <h1 className="font-serif text-5xl text-ink mb-4">Choose a subject.</h1>
      <p className="text-ink/70 mb-12 max-w-2xl">
        One question at a time. Instant feedback. No timer. Pick a subject below, or mix all subjects.
      </p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <SubjectCard subject="MIXED" label="Mixed (all subjects)" count={Array.from(map.values()).reduce((a: number, b: any) => a + b, 0)} highlight />
        {Object.entries(SUBJECT_LABELS).map(([key, label]) => (
          <SubjectCard key={key} subject={key} label={label} count={(map.get(key) as number) ?? 0} />
        ))}
      </div>
    </div>
  );
}

function SubjectCard({ subject, label, count, highlight }: any) {
  const disabled = count === 0 && !highlight;
  return (
    <Link
      href={disabled ? "#" : `/practice/play?subject=${subject}`}
      className={`block p-5 border ${highlight ? "border-brass bg-cream" : "border-rule/60 bg-cream"} ${disabled ? "opacity-50 pointer-events-none" : "hover:border-ink"}`}
    >
      <div className="flex items-baseline justify-between mb-2">
        <h3 className="font-serif text-xl text-ink">{label}</h3>
        <span className="text-xs text-ink/50">{count} q</span>
      </div>
      <div className="text-xs text-oxblood">{disabled ? "Coming soon" : "Practise →"}</div>
    </Link>
  );
}
