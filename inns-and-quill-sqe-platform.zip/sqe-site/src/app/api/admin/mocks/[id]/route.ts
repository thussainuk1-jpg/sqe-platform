import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

const schema = z.object({
  title: z.string().min(2),
  description: z.string().optional().nullable(),
  durationMins: z.number().int().min(5).max(360),
  published: z.boolean(),
});

async function assertAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user || (session.user as any).role !== "ADMIN") return null;
  return session;
}

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  if (!(await assertAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const data = schema.parse(await req.json());
  await prisma.mock.update({
    where: { id: params.id },
    data: { ...data, description: data.description || null },
  });
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  if (!(await assertAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  await prisma.mock.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
