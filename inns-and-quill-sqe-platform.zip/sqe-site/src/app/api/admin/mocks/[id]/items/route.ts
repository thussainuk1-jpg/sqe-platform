import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

const schema = z.object({ questionId: z.string().min(1) });

async function assertAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user || (session.user as any).role !== "ADMIN") return null;
  return session;
}

export async function POST(req: Request, { params }: { params: { id: string } }) {
  if (!(await assertAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { questionId } = schema.parse(await req.json());
  const existing = await prisma.mockItem.findFirst({
    where: { mockId: params.id, questionId },
  });
  if (existing) return NextResponse.json({ error: "Already added" }, { status: 409 });
  const last = await prisma.mockItem.findFirst({
    where: { mockId: params.id },
    orderBy: { position: "desc" },
  });
  const position = (last?.position ?? 0) + 1;
  await prisma.mockItem.create({
    data: { mockId: params.id, questionId, position },
  });
  return NextResponse.json({ ok: true });
}
