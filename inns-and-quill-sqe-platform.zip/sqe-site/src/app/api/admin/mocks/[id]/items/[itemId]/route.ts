import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

async function assertAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user || (session.user as any).role !== "ADMIN") return null;
  return session;
}

export async function DELETE(_req: Request, { params }: { params: { id: string; itemId: string } }) {
  if (!(await assertAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const item = await prisma.mockItem.findUnique({ where: { id: params.itemId } });
  if (!item || item.mockId !== params.id) return NextResponse.json({ error: "Not found" }, { status: 404 });

  await prisma.$transaction(async (tx) => {
    await tx.mockItem.delete({ where: { id: item.id } });
    const remaining = await tx.mockItem.findMany({
      where: { mockId: params.id },
      orderBy: { position: "asc" },
    });
    // Step 1: bump to a high range to dodge the unique index on (mockId, position)
    for (let i = 0; i < remaining.length; i++) {
      await tx.mockItem.update({ where: { id: remaining[i].id }, data: { position: 10_000 + i } });
    }
    // Step 2: settle to final positions 1..N
    for (let i = 0; i < remaining.length; i++) {
      await tx.mockItem.update({ where: { id: remaining[i].id }, data: { position: i + 1 } });
    }
  });

  return NextResponse.json({ ok: true });
}
