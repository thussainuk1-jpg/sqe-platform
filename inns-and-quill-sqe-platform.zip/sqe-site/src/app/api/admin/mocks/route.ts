import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

const schema = z.object({
  title: z.string().min(2),
  description: z.string().optional().default(""),
  durationMins: z.number().int().min(5).max(360),
});

async function assertAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user || (session.user as any).role !== "ADMIN") return null;
  return session;
}

export async function POST(req: Request) {
  if (!(await assertAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  try {
    const data = schema.parse(await req.json());
    const mock = await prisma.mock.create({
      data: { title: data.title, description: data.description, durationMins: data.durationMins },
    });
    return NextResponse.json({ id: mock.id });
  } catch (e: any) {
    return NextResponse.json({ error: e.errors?.[0]?.message ?? "Bad request" }, { status: 400 });
  }
}
