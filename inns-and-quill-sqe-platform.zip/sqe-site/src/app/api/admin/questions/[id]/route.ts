import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

const optionSchema = z.object({
  label: z.string().min(1).max(2),
  text: z.string().min(1),
  isCorrect: z.boolean(),
});

const schema = z.object({
  stem: z.string().min(10),
  subject: z.string().min(1),
  difficulty: z.enum(["EASY", "MEDIUM", "HARD"]),
  explanation: z.string().min(5),
  source: z.string().optional().nullable(),
  published: z.boolean(),
  options: z.array(optionSchema).min(2).max(8),
});

async function assertAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user || (session.user as any).role !== "ADMIN") return null;
  return session;
}

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  if (!(await assertAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  try {
    const data = schema.parse(await req.json());
    await prisma.$transaction([
      prisma.option.deleteMany({ where: { questionId: params.id } }),
      prisma.question.update({
        where: { id: params.id },
        data: {
          stem: data.stem,
          subject: data.subject as any,
          difficulty: data.difficulty as any,
          explanation: data.explanation,
          source: data.source || null,
          published: data.published,
          options: { create: data.options },
        },
      }),
    ]);
    return NextResponse.json({ id: params.id });
  } catch (e: any) {
    return NextResponse.json({ error: e.errors?.[0]?.message || e.message || "Bad request" }, { status: 400 });
  }
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  if (!(await assertAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  await prisma.question.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
