import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { stripe, stripeConfigured } from "@/lib/stripe";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";

export async function POST(req: Request) {
  if (!stripeConfigured()) return NextResponse.json({ error: "Stripe not configured" }, { status: 503 });
  const sig = headers().get("stripe-signature");
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!sig || !secret) return NextResponse.json({ error: "Bad webhook config" }, { status: 400 });

  const raw = await req.text();
  let event;
  try {
    event = stripe.webhooks.constructEvent(raw, sig, secret);
  } catch (e: any) {
    return NextResponse.json({ error: `Webhook signature failed: ${e.message}` }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const s = event.data.object as any;
    await prisma.donation.updateMany({
      where: { stripeSessionId: s.id },
      data: { status: "succeeded" },
    });
  } else if (event.type === "checkout.session.expired" || event.type === "checkout.session.async_payment_failed") {
    const s = event.data.object as any;
    await prisma.donation.updateMany({
      where: { stripeSessionId: s.id },
      data: { status: "failed" },
    });
  }
  return NextResponse.json({ received: true });
}
