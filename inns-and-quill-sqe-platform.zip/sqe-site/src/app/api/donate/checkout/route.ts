import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { stripe, stripeConfigured } from "@/lib/stripe";

const schema = z.object({ amount: z.number().int().min(1).max(5000) });

export async function POST(req: Request) {
  if (!stripeConfigured()) {
    return NextResponse.json({ error: "Donations are not configured yet. Please check back soon." }, { status: 503 });
  }

  const { amount } = schema.parse(await req.json());
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  const userEmail = session?.user?.email ?? undefined;

  const origin = new URL(req.url).origin;
  const checkout = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [{
      price_data: {
        currency: "gbp",
        product_data: {
          name: "Donation — Inns & Quill SQE1 Practice",
          description: "Supports free SQE1 practice for the next candidate.",
        },
        unit_amount: amount * 100,
      },
      quantity: 1,
    }],
    customer_email: userEmail,
    success_url: `${origin}/donate/thanks?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${origin}/donate`,
    metadata: { userId: userId ?? "", amountGBP: String(amount) },
  });

  await prisma.donation.create({
    data: {
      userId: userId ?? null,
      email: userEmail ?? null,
      amountPence: amount * 100,
      currency: "gbp",
      stripeSessionId: checkout.id,
      status: "pending",
    },
  });

  return NextResponse.json({ url: checkout.url });
}
