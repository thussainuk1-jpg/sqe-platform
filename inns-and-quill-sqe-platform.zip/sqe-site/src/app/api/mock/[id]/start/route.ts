import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.redirect(new URL("/login", _req.url));
  const userId = (session.user as any).id as string;

  const mock = await prisma.mock.findUnique({
    where: { id: params.id },
    include: { _count: { select: { items: true } } },
  });
  if (!mock || !mock.published) return NextResponse.json({ error: "Not found" }, { status: 404 });

  // Reuse an in-progress session if it exists
  const existing = await prisma.mockSession.findFirst({
    where: { userId, mockId: mock.id, finishedAt: null },
  });
  const ms = existing ?? (await prisma.mockSession.create({
    data: { userId, mockId: mock.id, total: mock._count.items },
  }));

  return NextResponse.redirect(new URL(`/mock/${mock.id}/session/${ms.id}`, _req.url));
}
