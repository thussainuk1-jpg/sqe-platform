import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function POST(_req: Request, { params }: { params: { sessionId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const userId = (session.user as any).id as string;

  const ms = await prisma.mockSession.findUnique({
    where: { id: params.sessionId },
    include: { attempts: true, mock: { include: { _count: { select: { items: true } } } } },
  });
  if (!ms || ms.userId !== userId) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (!ms.finishedAt) {
    const score = ms.attempts.filter(a => a.correct).length;
    await prisma.mockSession.update({
      where: { id: ms.id },
      data: { finishedAt: new Date(), score, total: ms.mock._count.items },
    });
  }
  return NextResponse.json({ ok: true, mockId: ms.mockId });
}
