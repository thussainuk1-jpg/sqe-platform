import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

const schema = z.object({
  questionId: z.string().min(1),
  selectedLabel: z.string().min(1).max(2),
});

export async function POST(req: Request, { params }: { params: { sessionId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const userId = (session.user as any).id as string;

  const data = schema.parse(await req.json());
  const ms = await prisma.mockSession.findUnique({ where: { id: params.sessionId } });
  if (!ms || ms.userId !== userId) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (ms.finishedAt) return NextResponse.json({ error: "Session finished" }, { status: 400 });

  const q = await prisma.question.findUnique({
    where: { id: data.questionId },
    include: { options: true },
  });
  if (!q) return NextResponse.json({ error: "Question not found" }, { status: 404 });
  const correctOpt = q.options.find(o => o.isCorrect);
  if (!correctOpt) return NextResponse.json({ error: "Bad question" }, { status: 500 });

  // Upsert by deleting prior attempt for this session+question, then creating new
  await prisma.attempt.deleteMany({
    where: { mockSessionId: ms.id, questionId: q.id, userId },
  });
  await prisma.attempt.create({
    data: {
      userId,
      questionId: q.id,
      selectedOption: data.selectedLabel,
      correct: data.selectedLabel === correctOpt.label,
      mode: "mock",
      mockSessionId: ms.id,
    },
  });
  return NextResponse.json({ ok: true });
}
