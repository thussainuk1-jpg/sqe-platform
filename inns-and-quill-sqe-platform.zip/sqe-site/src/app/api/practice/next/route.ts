import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { SUBJECT_LABELS, SUBJECTS } from "@/lib/subjects";

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const subject = searchParams.get("subject") || "MIXED";

  const where: any = { published: true };
  if (subject !== "MIXED" && SUBJECTS.includes(subject)) where.subject = subject;

  const count = await prisma.question.count({ where });
  if (count === 0) {
    return NextResponse.json({ error: "No questions available for this subject yet." }, { status: 404 });
  }
  const skip = Math.floor(Math.random() * count);
  const question = await prisma.question.findFirst({
    where,
    skip,
    include: { options: { select: { id: true, label: true, text: true } } },
  });
  if (!question) return NextResponse.json({ error: "Question not found" }, { status: 404 });

  return NextResponse.json({
    question: {
      id: question.id,
      stem: question.stem,
      subject: question.subject,
      subjectLabel: SUBJECT_LABELS[question.subject] ?? question.subject,
      options: question.options.sort((a, b) => a.label.localeCompare(b.label)),
    },
  });
}
