import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

const schema = z.object({
  questionId: z.string().min(1),
  selectedLabel: z.string().min(1).max(2),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const userId = (session.user as any).id as string;

  const body = await req.json();
  const data = schema.parse(body);

  const q = await prisma.question.findUnique({
    where: { id: data.questionId },
    include: { options: true },
  });
  if (!q) return NextResponse.json({ error: "Question not found" }, { status: 404 });

  const correctOpt = q.options.find(o => o.isCorrect);
  if (!correctOpt) return NextResponse.json({ error: "Question has no correct option" }, { status: 500 });

  const isCorrect = data.selectedLabel === correctOpt.label;

  await prisma.attempt.create({
    data: {
      userId,
      questionId: q.id,
      selectedOption: data.selectedLabel,
      correct: isCorrect,
      mode: "practice",
    },
  });

  return NextResponse.json({
    correct: isCorrect,
    correctLabel: correctOpt.label,
    explanation: q.explanation,
    selectedLabel: data.selectedLabel,
  });
}
