import { prisma } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { SUBJECT_LABELS } from "@/lib/subjects";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function MyProgress() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login?callbackUrl=/me");
  const userId = (session.user as any).id as string;

  const [attempts, mockSessions] = await Promise.all([
    prisma.attempt.findMany({
      where: { userId },
      include: { question: { select: { subject: true } } },
    }),
    prisma.mockSession.findMany({
      where: { userId, finishedAt: { not: null } },
      include: { mock: { select: { title: true, id: true } } },
      orderBy: { finishedAt: "desc" },
      take: 20,
    }),
  ]);

  const total = attempts.length;
  const correct = attempts.filter(a => a.correct).length;
  const pct = total ? Math.round((correct / total) * 100) : 0;

  const bySubject: Record<string, { correct: number; total: number }> = {};
  attempts.forEach(a => {
    const s = a.question.subject;
    bySubject[s] ??= { correct: 0, total: 0 };
    bySubject[s].total += 1;
    if (a.correct) bySubject[s].correct += 1;
  });
  const subjects = Object.entries(bySubject).sort((a, b) => (a[1].correct / a[1].total) - (b[1].correct / b[1].total));

  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <div className="text-xs uppercase tracking-[0.25em] text-brass mb-3">My progress</div>
      <h1 className="font-serif text-5xl text-ink mb-2">Hello, {session.user.name || "Candidate"}.</h1>
      <p className="text-ink/60 mb-12">A quiet record of your practice so far.</p>

      <div className="grid sm:grid-cols-3 gap-4 mb-12">
        <Stat label="Questions answered" value={total} />
        <Stat label="Correct" value={correct} />
        <Stat label="Accuracy" value={`${pct}%`} />
      </div>

      <h2 className="font-serif text-2xl text-ink mb-4">Weakest subjects first</h2>
      {subjects.length === 0 ? (
        <div className="card text-center text-ink/60">
          You haven&rsquo;t practised yet. <Link href="/practice" className="text-oxblood underline">Start now</Link>.
        </div>
      ) : (
        <div className="space-y-2 mb-12">
          {subjects.map(([subj, s]) => {
            const p = Math.round((s.correct / s.total) * 100);
            return (
              <div key={subj} className="card flex items-center gap-6">
                <div className="flex-1">
                  <div className="text-sm text-ink mb-2">{SUBJECT_LABELS[subj] ?? subj}</div>
                  <div className="h-2 bg-rule/40">
                    <div className={`h-full ${p >= 60 ? "bg-forest" : p >= 40 ? "bg-brass" : "bg-oxblood"}`} style={{ width: `${p}%` }} />
                  </div>
                </div>
                <div className="text-right text-sm">
                  <div className="font-serif text-xl">{p}%</div>
                  <div className="text-xs text-ink/60">{s.correct}/{s.total}</div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <h2 className="font-serif text-2xl text-ink mb-4">Recent mocks</h2>
      {mockSessions.length === 0 ? (
        <div className="card text-center text-ink/60">
          You haven&rsquo;t sat a mock yet. <Link href="/mock" className="text-oxblood underline">See available mocks</Link>.
        </div>
      ) : (
        <div className="space-y-2">
          {mockSessions.map(ms => {
            const p = ms.total > 0 ? Math.round(((ms.score ?? 0) / ms.total) * 100) : 0;
            return (
              <Link
                key={ms.id}
                href={`/mock/${ms.mockId}/result/${ms.id}`}
                className="card flex items-center justify-between hover:border-ink"
              >
                <div>
                  <div className="font-serif text-xl text-ink">{ms.mock.title}</div>
                  <div className="text-xs text-ink/60">{ms.finishedAt?.toLocaleString()}</div>
                </div>
                <div className="text-right">
                  <div className="font-serif text-2xl">{p}%</div>
                  <div className="text-xs text-ink/60">{ms.score}/{ms.total}</div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: any }) {
  return (
    <div className="card">
      <div className="text-xs uppercase tracking-wider text-ink/50 mb-2">{label}</div>
      <div className="font-serif text-3xl text-ink">{value}</div>
    </div>
  );
}
