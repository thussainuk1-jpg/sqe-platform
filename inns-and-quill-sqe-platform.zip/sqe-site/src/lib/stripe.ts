import Stripe from "stripe";

const key = process.env.STRIPE_SECRET_KEY;

export const stripe = key
  ? new Stripe(key, { apiVersion: "2024-11-20.acacia" })
  : (null as unknown as Stripe);

export function stripeConfigured() {
  return !!process.env.STRIPE_SECRET_KEY;
}
