export const SUBJECT_LABELS: Record<string, string> = {
  BUSINESS_LAW_PRACTICE: "Business Law & Practice",
  DISPUTE_RESOLUTION: "Dispute Resolution",
  CONTRACT: "Contract",
  TORT: "Tort",
  LEGAL_SYSTEM: "Legal System of England & Wales",
  CONSTITUTIONAL: "Constitutional & Administrative Law / EU",
  PROPERTY_PRACTICE: "Property Practice",
  WILLS_ESTATES: "Wills & Estates Administration",
  SOLICITORS_ACCOUNTS: "Solicitors Accounts",
  LAND_LAW: "Land Law",
  TRUSTS: "Trusts",
  CRIMINAL_LAW: "Criminal Law",
  CRIMINAL_PRACTICE: "Criminal Practice",
  ETHICS: "Ethics & Professional Conduct",
};

export const SUBJECTS = Object.keys(SUBJECT_LABELS);
